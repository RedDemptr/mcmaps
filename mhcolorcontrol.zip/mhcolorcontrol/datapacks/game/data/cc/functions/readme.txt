if you're here you're in for a treat, sorry about the mess converting cmd blocks to functions was not pretty
nothing is organized but the main folder was the old command blocks
- RedDemptr